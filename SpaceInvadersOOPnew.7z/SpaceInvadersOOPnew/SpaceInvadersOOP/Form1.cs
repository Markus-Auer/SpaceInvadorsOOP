﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceInvadersOOP
{
    public partial class Form1 : Form
    {
        int state = 0;
        int stateBefore;

        bool leftout = false;
        bool rightout = false;

        public string direction = "non";

        public Form1()
        {
            InitializeComponent();
            KeyDown += new KeyEventHandler(Form1_KeyDown);            
        }

        Projectile test;
        GameElements player1;



        public void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (!rightout)
            {
                if (e.KeyCode == Keys.Right)
                {
                    state = 1;
                    direction = "r";
                }
            }
            if (!leftout)
            {
                if (e.KeyCode == Keys.Left)
                {
                    state = 2;
                    direction = "l";
                }
            }
                if(e.KeyCode == Keys.Space)
            {
                state = 3;
            }
            
            positionXplayer2.Text = this.Width.ToString();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            test = new Projectile(this, pBplayer);
            player1 = new GameElements(this, pBplayer);

        }

        private void Timer1_Tick(object sender, EventArgs e)
        {

            
            switch (state)
            {
                case 1:
                    pBplayer.Left += player1.move(direction);
                    stateBefore = 1;
                    positionXplayer.Text = pBplayer.Location.X.ToString();
                    break;
                case 2:
                    pBplayer.Left -= player1.move(direction);
                    stateBefore = 2;
                    positionXplayer.Text = pBplayer.Location.X.ToString();
                    break;
                case 3:
                    test.posX_ = pBplayer.Location.X;
                    test.posY_ = pBplayer.Location.Y;                   
                    test.draw();  
                    break;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            state = 0;
        }
    }
}
