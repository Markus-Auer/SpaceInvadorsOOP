﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using System.Data;


namespace SpaceInvadersOOP
{   
    class Projectile
    {
        public int posX_ { get; set; }
        public int posY_ { get; set; }
        public Form form1 { get; set; }
        public Control Control { get; set; }



        public Projectile(Form form, Control control, int playerPosX = 0, int playerPosY = 0)
        {
            form1 = form;
            Control = control;
            posX_ = playerPosX;
            posY_ = playerPosY;
        }






        public void draw()
        {

            PictureBox projectile = new PictureBox();
            projectile.Location = new System.Drawing.Point(posX_, posY_);
            projectile.Name = "projectile";
            projectile.Size = new System.Drawing.Size(10, 15);
            projectile.BackColor = Color.Black;
            form1.Controls.Add(projectile);
        }
       

    }
}
