﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceInvadersOOP
{
    class GameElements
    {
        public int speed_ { get; set; }
        public int speed = 5;
        public Form form1 { get; set; }
        public Control Control { get; set; }
        public int posX_ { get; set; }



        public GameElements(Form form, Control control)
        {
            form1 = form;
            Control = control;

        }

        public int move(string richtung)
        {
            int x = Control.Location.X;
            if (x <= 0)
            {
                if (richtung == "l" )
                {
                    return 0;
                }
                else
                {
                    speed_ = speed;
                    return speed_;
                }
            }
            if (x >= form1.Width)
            {
                if (richtung == "r")
                {
                    return 0;
                }
                else
                {
                    speed_ = speed;
                    return speed_;

                }
            }
            speed_ = speed;
            return speed_;
        }



        }
    }
